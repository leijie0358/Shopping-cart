VirtualKeyboard.Langs.JP.processChar;
